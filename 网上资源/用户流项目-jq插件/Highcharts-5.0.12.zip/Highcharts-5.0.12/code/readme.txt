﻿当前目录下的文件为 JavaScript 版本的 Highcharts；


css 目录下的文件为 CSS 版本的 Highcharts （5.0.0 新增，即用 CSS 控制图表样式）。



如果您还有其他疑问，欢迎与我们保持联系：


-Q Q: 3027488402
-
邮箱：support@jianshukeji.com

-电话：0571 - 8620 8605